/*!
 *  Liquid Slider v2.0.8
 *  http://liquidslider.com
 *  GPL license
 */
;if(typeof Object.create!=="function"){Object.create=function(b){function a(){}a.prototype=b;return new a()}}(function(d,c,a,e){var b={
<?php
	// peace out
	header( "Location: mywebsite/index.php" );
